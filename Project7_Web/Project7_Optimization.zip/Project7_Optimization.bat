@echo off
setlocal EnableExtensions
title Project7 - Windows Optimization Utility
mode con: cols=82 lines=30
color 0B
cd /d "%~dp0"

rem ============================================================
rem Project7 - simple Windows optimization utility
rem No registry editing. No third-party software.
rem ============================================================

fltmc >nul 2>&1
if not "%errorlevel%"=="0" (
    powershell.exe -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

set "LOG=%~dp0Project7.log"
if not exist "%LOG%" type nul > "%LOG%"

:MENU
cls
echo.
echo   +--------------------------------------------------------------------------+
echo   ^|                              PROJECT7                                    ^|
echo   ^|                    Windows Optimization Utility                          ^|
echo   +--------------------------------------------------------------------------+
echo.
echo   No nonsense code. Simply Optimization.
echo.
echo   [1] Quick Optimize
echo   [2] Clean Temporary Files
echo   [3] Optimize System Drive
echo   [4] Repair Windows System Files
echo   [5] Refresh Network
echo   [6] Use High Performance Power Plan
echo   [7] Restore Balanced Power Plan
echo   [8] View Log
echo   [Q] Exit
echo.
echo   --------------------------------------------------------------------------
echo.
choice /c 12345678Q /n /m "   Select an option: "

if errorlevel 9 goto EXIT
if errorlevel 8 goto LOGVIEW
if errorlevel 7 goto BALANCED
if errorlevel 6 goto HIGHPOWER
if errorlevel 5 goto NETWORK
if errorlevel 4 goto REPAIR
if errorlevel 3 goto DRIVE
if errorlevel 2 goto TEMP
if errorlevel 1 goto QUICK

:QUICK
cls
call :HEADER "QUICK OPTIMIZE"
echo.
echo   Project7 will perform four useful maintenance tasks.
echo.
echo   - Clean temporary files
echo   - Flush DNS cache
echo   - Optimize the system drive
echo   - Empty the Recycle Bin
echo.
echo   No registry changes are made.
echo.
pause
cls
call :HEADER "QUICK OPTIMIZE"
echo.
call :TEMP_WORK
call :NETWORK_WORK
call :DRIVE_WORK
call :BIN_WORK
echo.
echo   Quick optimization is complete.
echo.
echo   Press any key to return to the main menu.
pause >nul
goto MENU

:TEMP
cls
call :HEADER "TEMPORARY FILE CLEANUP"
echo.
call :TEMP_WORK
echo.
echo   Cleanup complete.
echo.
pause
goto MENU

:TEMP_WORK
echo   [1/4] Cleaning user temporary files...
del /f /s /q "%TEMP%\*" >nul 2>&1
for /d %%D in ("%TEMP%\*") do rd /s /q "%%D" >nul 2>&1

echo   [2/4] Cleaning Windows temporary files...
del /f /s /q "%SystemRoot%\Temp\*" >nul 2>&1
for /d %%D in ("%SystemRoot%\Temp\*") do rd /s /q "%%D" >nul 2>&1

echo   [3/4] Cleaning thumbnail cache...
del /f /q "%LocalAppData%\Microsoft\Windows\Explorer\thumbcache_*.db" >nul 2>&1

echo   [4/4] Recording result...
echo [%date% %time%] Temporary cleanup completed.>>"%LOG%"
exit /b

:DRIVE
cls
call :HEADER "SYSTEM DRIVE OPTIMIZATION"
echo.
echo   Windows will choose the appropriate optimization for your drive.
echo   For supported SSDs this includes TRIM.
echo.
call :DRIVE_WORK
echo.
pause
goto MENU

:DRIVE_WORK
echo   Optimizing C: ...
defrag C: /O /U
if errorlevel 1 (
    echo   Result: Windows reported an issue.
    echo [%date% %time%] Drive optimization reported an error.>>"%LOG%"
) else (
    echo   Result: Optimization completed.
    echo [%date% %time%] Drive optimization completed.>>"%LOG%"
)
exit /b

:REPAIR
cls
call :HEADER "WINDOWS SYSTEM REPAIR"
echo.
echo   DISM and SFC are built into Windows and can repair damaged
echo   Windows components and protected system files.
echo.
echo   This can take several minutes.
echo.
echo   [1/2] Running DISM...
echo.
DISM.exe /Online /Cleanup-Image /RestoreHealth
echo.
echo   [2/2] Running SFC...
echo.
sfc /scannow
echo.
echo   Repair pass complete.
echo [%date% %time%] DISM/SFC repair pass completed.>>"%LOG%"
echo.
pause
goto MENU

:NETWORK
cls
call :HEADER "NETWORK REFRESH"
echo.
echo   This refreshes common Windows networking components.
echo   Your connection may briefly disconnect.
echo.
call :NETWORK_WORK
echo.
echo   Network refresh complete.
pause
goto MENU

:NETWORK_WORK
echo   [1/3] Flushing DNS cache...
ipconfig /flushdns >nul

echo   [2/3] Resetting Winsock...
netsh winsock reset

echo   [3/3] Refreshing IP configuration...
ipconfig /release >nul
ipconfig /renew >nul

echo [%date% %time%] Network refresh completed.>>"%LOG%"
exit /b

:BIN_WORK
echo   Emptying Recycle Bin...
powershell.exe -NoProfile -Command "Clear-RecycleBin -Force -ErrorAction SilentlyContinue"
echo [%date% %time%] Recycle Bin cleared.>>"%LOG%"
exit /b

:HIGHPOWER
cls
call :HEADER "HIGH PERFORMANCE POWER PLAN"
echo.
echo   This switches Windows to its built-in High Performance plan.
echo.
echo   It may improve responsiveness on some systems, but can use
echo   more power and generate more heat.
echo.
powercfg /setactive SCHEME_MIN
if errorlevel 1 (
    echo   Could not activate the High Performance plan.
) else (
    echo   High Performance plan activated.
    echo [%date% %time%] High Performance plan activated.>>"%LOG%"
)
echo.
pause
goto MENU

:BALANCED
cls
call :HEADER "BALANCED POWER PLAN"
echo.
powercfg /setactive SCHEME_BALANCED
if errorlevel 1 (
    echo   Could not activate the Balanced plan.
) else (
    echo   Balanced power plan restored.
    echo [%date% %time%] Balanced power plan activated.>>"%LOG%"
)
echo.
pause
goto MENU

:LOGVIEW
cls
call :HEADER "PROJECT7 LOG"
echo.
type "%LOG%"
echo.
echo   --------------------------------------------------------------------------
pause
goto MENU

:HEADER
echo.
echo   +--------------------------------------------------------------------------+
echo   ^|                              PROJECT7                                    ^|
echo   ^|                          %~1                         ^|
echo   +--------------------------------------------------------------------------+
exit /b

:EXIT
cls
echo.
echo   +--------------------------------------------------------------------------+
echo   ^|                              PROJECT7                                    ^|
echo   +--------------------------------------------------------------------------+
echo.
echo   Thanks for using Project7.
echo.
echo   No registry changes were made.
echo.
timeout /t 2 /nobreak >nul
exit /b
